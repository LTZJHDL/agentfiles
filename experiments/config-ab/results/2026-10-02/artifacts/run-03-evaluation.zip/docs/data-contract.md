# Field Ledger 数据约定

Field Ledger 整理来自多个来源的观测记录。导入会保留修订历史；查询和统计呈现每条记录的当前版本。

## 记录与修订

记录由 `(source, external_id)` 共同标识。不同来源可以使用相同编号。两者均为去掉首尾空白后的非空文本，区分大小写，不限制分隔符或 Unicode 字符。

每个版本包含 `source`、`external_id`、`day`、`category`、`value` 和 `note`。`day` 是严格的 `YYYY-MM-DD` 格式及有效日历日期；`category` 是去掉首尾空白后的非空文本；`value` 是十进制整数，范围为 -1000000000 到 1000000000；`note` 是去掉首尾空白后的文本，省略时为空字符串。其他文本字段也去掉首尾空白。

首次出现的记录为新增。同一标识的内容发生变化时追加修订，日期和分类也可以改变。全部内容相同的记录为未变化，不追加修订。修订的先后由导入顺序确定，与观测日期无关。

## CSV 导入

UTF-8 CSV（允许 BOM）必须包含 `source,external_id,day,category,value` 列，可以包含 `note` 列及其他具名列；额外具名列被忽略。缺少必需列、重复列名或无法读取的文件属于整份输入错误，退出码为 2，并在 stderr 解释原因；这类错误不创建或改变数据库。

数据行缺失必需值、格式错误，或者比表头多出字段时，跳过该行并记录诊断。有效行按文件顺序处理，包括同一文件中多次出现的同一标识。后续行相对于前面有效行处理后的状态判断新增、更新或未变化。正式导入的所有有效行在一次事务中提交。

导入摘要的 JSON 对象包含 `inserted`、`updated`、`unchanged`、`invalid` 四个计数，以及 `errors` 数组。每条错误包含 `row` 和非空的 `message`。`row` 按 CSV 记录计数，从表头后的 2 开始，不是含换行字段的物理行号。没有无效行时退出码为 0，有无效行时为 1；正式导入仍然提交有效行。整份输入或执行失败时退出码为 2。人类可读输出表达同样的信息。

### 导入预览

`import observations.csv --dry-run` 按正式导入的规则计算摘要，但不保存任何记录或修订。预览只读现有数据库；数据库不存在时按空库计算，不创建数据库文件或缺失的父目录。CSV 有行错误或整份输入无效时也不创建这些文件或目录。

`--dry-run --json` 返回上述五个字段，并增加 `"dry_run": true`；正式导入的 JSON 不增加这个字段。相同输入和数据库在没有外部变化时，预览与正式导入的 `inserted`、`updated`、`unchanged`、`invalid`、`errors` 相同。同一文件的重复标识仍按有效行顺序计算，后续行与前面行处理后的状态比较。

预览沿用退出码 0、1、2。文本输出明确说明这是尚未保存的预览，并提示移除 `--dry-run` 后正式导入。应先查看错误、修正输入并重新预览，再决定是否导入。预览不保证后续写入成功，也不锁定或保留数据库状态；正式导入仍需要父目录存在及写入权限。本工具不支持并发写入。

## 查询与统计

`list --json` 返回当前记录组成的 JSON 数组，每项恰好包含上述六个字段，按 `(source, external_id)` 排序。历史版本不重复出现在列表里。

统计先确定每个标识的最新修订，再按日期和分类过滤当前记录。`--from` 和 `--to` 均包含端点，省略时不设对应边界；`--category` 精确匹配分类。起止日期非法或起点晚于终点时，退出码为 2。

`report --json` 返回 `count`、`total` 和 `groups`。`count` 是当前记录数，`total` 是当前记录的整数值之和。`groups` 按 `(day, category)` 排序，每组包含 `day`、`category`、`count`、`total`。空结果为 `{"count": 0, "total": 0, "groups": []}`。所有总数与分组都使用相同的筛选结果。

## 命令接口

从项目根目录运行 Python 3.11 或以上版本，无需安装依赖。本机的 `python` 指 `C:\Users\LTZJH\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe`；PowerShell 用 `&` 调用，完整可复制示例见 [README](../README.md)。

```text
python -m fieldledger --db observations.sqlite import observations.csv --dry-run
python -m fieldledger --db observations.sqlite import observations.csv --dry-run --json
python -m fieldledger --db observations.sqlite import observations.csv --json
python -m fieldledger --db observations.sqlite list --json
python -m fieldledger --db observations.sqlite report --from 2026-01-01 --to 2026-01-31 --category rain --json
python -m unittest discover -s tests -v
```

`--db` 是主命令选项，放在 `import`、`list` 或 `report` 之前。JSON 模式的 stdout 只包含一个 JSON 值；说明及失败诊断使用 stderr。正式导入的数据库父目录须已存在，首次导入可以创建数据库。`list` 和 `report` 查询不存在的数据库时返回空结果，不创建文件。
