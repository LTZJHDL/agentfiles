import csv
from contextlib import closing
import json
from pathlib import Path
import sqlite3
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit

from fieldledger.csv_input import read_csv
from fieldledger.importer import ImportSummary, import_csv
from fieldledger.model import InputError


HEADER = ["source", "external_id", "day", "category", "value", "note"]
SUMMARY_FIELDS = {"inserted", "updated", "unchanged", "invalid", "errors"}


class PreviewTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.db = self.root / "ledger.sqlite"
        self.csv = self.root / "input.csv"

    def write_rows(self, rows):
        with self.csv.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(HEADER)
            writer.writerows(rows)

    def cli(self, *args, db=None):
        return subprocess.run(
            [sys.executable, "-m", "fieldledger", "--db", str(db or self.db), *args],
            capture_output=True, text=True, encoding="utf-8",
            cwd=Path(__file__).resolve().parents[1],
        )

    def seed_history(self):
        self.write_rows([
            ["north", "same", "2026-01-10", "rain", "10", ""],
            ["west", "same", "2026-01-10", "rain", "20", ""],
        ])
        import_csv(self.csv, self.db)
        self.write_rows([["north", "same", "2026-01-10", "rain", "11", ""]])
        import_csv(self.csv, self.db)

    def history(self):
        connection = sqlite3.connect(self.db.resolve().as_uri() + "?mode=ro", uri=True)
        try:
            return connection.execute("SELECT * FROM revisions ORDER BY revision_id").fetchall()
        finally:
            connection.close()

    def database_files(self):
        return {path.name: path.read_bytes() for path in self.root.glob(self.db.name + "*")}

    def test_preview_matches_saved_import_with_history_and_sequential_duplicates(self):
        self.seed_history()
        self.write_rows([
            [" north ", "same", "2026-01-10", "rain", "11", ""],
            ["north", "same", "2026-01-10", "rain", "12", ""],
            ["north", "same", "2026-02-30", "rain", "99", ""],
            ["north", "same", "2026-01-10", "rain", "12", ""],
            ["south", "new", "2026-01-11", "snow", "5", "two\nlines"],
            ["south", "new", "2026-01-11", "snow", "6", "two\nlines"],
            ["south", "new", "2026-01-11", "snow", "6", "two\nlines"],
            ["north", "same", "2026-01-10", "rain", "11", ""],
            ["north", "extra", "2026-01-10", "rain", "1", "", "extra"],
            ["west", "same", "2026-01-10", "rain", "20", ""],
        ])
        before_files = self.database_files()
        before_history = self.history()
        preview = import_csv(self.csv, self.db, dry_run=True)
        self.assertIsInstance(preview, ImportSummary)
        self.assertEqual(set(preview.as_dict()), SUMMARY_FIELDS)
        self.assertEqual(preview.as_dict(), {
            "inserted": 1, "updated": 3, "unchanged": 4, "invalid": 2,
            "errors": [error.as_dict() for error in read_csv(self.csv).errors],
        })
        self.assertEqual([error.row for error in preview.errors], [4, 10])
        self.assertTrue(all(error.message for error in preview.errors))
        self.assertEqual(self.database_files(), before_files)
        self.assertEqual(self.history(), before_history)

        saved = import_csv(self.csv, self.db)
        self.assertEqual(saved.as_dict(), preview.as_dict())
        history = self.history()
        self.assertEqual(history[:len(before_history)], before_history)
        self.assertEqual([row[5] for row in history], [10, 20, 11, 12, 5, 6, 11])

    def test_missing_database_and_parents_stay_missing_for_all_row_outcomes(self):
        cases = [
            ([["north", "one", "2026-01-10", "rain", "1", ""]], 1, 0),
            ([["north", "one", "2026-01-10", "rain", "1", ""],
              ["north", "bad", "2026-01-10", "rain", "oops", ""]], 1, 1),
            ([["north", "bad", "2026-01-10", "rain", "oops", ""]], 0, 1),
            ([], 0, 0),
        ]
        for database in [self.db, self.root / "absent" / "nested" / "ledger.sqlite"]:
            for rows, inserted, invalid in cases:
                with self.subTest(database=database, rows=rows):
                    self.write_rows(rows)
                    preview = import_csv(self.csv, database, dry_run=True)
                    self.assertEqual(preview.as_dict()["inserted"], inserted)
                    self.assertEqual(preview.invalid, invalid)
                    result = self.cli("import", str(self.csv), "--dry-run", "--json", db=database)
                    self.assertEqual(result.returncode, 1 if invalid else 0, result.stderr)
                    self.assertEqual(json.loads(result.stdout), {**preview.as_dict(), "dry_run": True})
                    self.assertEqual(result.stderr, "")
                    self.assertFalse(database.exists())
                    if database.parent != self.root:
                        self.assertFalse((self.root / "absent").exists())

    def test_whole_input_errors_preserve_existing_or_missing_database(self):
        self.seed_history()
        before = self.database_files()
        inputs = [
            b"source,external_id\nnorth,one\n",
            b"source,external_id,day,category,value,value\n",
            b"source,external_id,day,category,value,\n",
            b"source,external_id,day,category,value\n\xff",
            b'source,external_id,day,category,value\n"unterminated',
            None,
        ]
        for content in inputs:
            csv_path = self.root / "missing.csv" if content is None else self.csv
            if content is not None:
                self.csv.write_bytes(content)
            for database in [self.db, self.root / "absent" / "ledger.sqlite"]:
                with self.subTest(content=content, database=database):
                    with self.assertRaises(InputError):
                        import_csv(csv_path, database, dry_run=True)
                    result = self.cli("import", str(csv_path), "--dry-run", "--json", db=database)
                    self.assertEqual(result.returncode, 2)
                    self.assertEqual(result.stdout, "")
                    self.assertTrue(result.stderr.strip())
                    self.assertEqual(self.database_files(), before)
                    self.assertFalse((self.root / "absent").exists())

    def test_existing_empty_database_is_previewed_without_initializing_schema(self):
        self.write_rows([["north", "one", "2026-01-10", "rain", "1", ""]])
        for kind in ["zero-byte", "empty-sqlite"]:
            database = self.root / (kind + ".sqlite")
            if kind == "zero-byte":
                database.touch()
            else:
                with closing(sqlite3.connect(database)) as connection:
                    connection.execute("PRAGMA user_version = 1")
            with self.subTest(kind=kind):
                before = database.read_bytes()
                preview = import_csv(self.csv, database, dry_run=True)
                self.assertEqual(preview.inserted, 1)
                self.assertEqual(database.read_bytes(), before)
                saved = import_csv(self.csv, database)
                self.assertEqual(saved.as_dict(), preview.as_dict())

    def test_preview_uses_read_only_connection_on_read_only_database(self):
        self.db = self.root / "观测 #1%.sqlite"
        self.seed_history()
        self.write_rows([["north", "same", "2026-01-10", "rain", "12", ""]])
        before = self.database_files()
        original_connect = sqlite3.connect
        connections = []
        attempted_writes = []
        write_actions = {
            sqlite3.SQLITE_INSERT, sqlite3.SQLITE_UPDATE, sqlite3.SQLITE_DELETE,
            sqlite3.SQLITE_CREATE_TABLE, sqlite3.SQLITE_CREATE_INDEX,
            sqlite3.SQLITE_CREATE_TRIGGER, sqlite3.SQLITE_CREATE_VIEW,
            sqlite3.SQLITE_DROP_TABLE, sqlite3.SQLITE_DROP_INDEX,
            sqlite3.SQLITE_DROP_TRIGGER, sqlite3.SQLITE_DROP_VIEW,
            sqlite3.SQLITE_ALTER_TABLE, sqlite3.SQLITE_ATTACH, sqlite3.SQLITE_DETACH,
        }

        def authorizer(action, arg1, arg2, database, trigger):
            if action in write_actions or (action == sqlite3.SQLITE_PRAGMA and arg2 is not None):
                attempted_writes.append((action, arg1, arg2))
                return sqlite3.SQLITE_DENY
            return sqlite3.SQLITE_OK

        def read_only_connect(database, *args, **kwargs):
            self.assertIs(kwargs.get("uri"), True)
            self.assertEqual(parse_qs(urlsplit(str(database)).query).get("mode"), ["ro"])
            connection = original_connect(database, *args, **kwargs)
            connection.set_authorizer(authorizer)
            connections.append(connection)
            return connection

        previous_mode = self.db.stat().st_mode
        self.db.chmod(stat.S_IREAD)
        try:
            with patch("fieldledger.store.sqlite3.connect", side_effect=read_only_connect):
                preview = import_csv(self.csv, self.db, dry_run=True)
            self.assertEqual(preview.updated, 1)
            self.assertTrue(connections, "an existing database must be read to classify updates")
            self.assertEqual(attempted_writes, [])
            self.assertEqual(self.database_files(), before)
        finally:
            self.db.chmod(previous_mode)

    def test_cli_json_preview_and_saved_import_have_same_summary_and_status(self):
        self.seed_history()
        self.write_rows([
            ["north", "same", "2026-01-10", "rain", "12", ""],
            ["north", "bad", "2026-01-10", "rain", "oops", ""],
        ])
        before = self.database_files()
        preview = self.cli("import", str(self.csv), "--dry-run", "--json")
        self.assertEqual(preview.returncode, 1, preview.stderr)
        preview_json = json.loads(preview.stdout)
        self.assertEqual(set(preview_json), SUMMARY_FIELDS | {"dry_run"})
        self.assertIs(preview_json.pop("dry_run"), True)
        self.assertEqual(preview.stderr, "")
        self.assertEqual(self.database_files(), before)
        saved = self.cli("import", str(self.csv), "--json")
        self.assertEqual(saved.returncode, 1, saved.stderr)
        self.assertEqual(json.loads(saved.stdout), preview_json)
        self.assertEqual(set(json.loads(saved.stdout)), SUMMARY_FIELDS)
        self.assertEqual(saved.stderr, "")

    def test_cli_text_marks_preview_and_explains_how_to_save(self):
        self.write_rows([
            ["north", "one", "2026-01-10", "rain", "1", ""],
            ["north", "bad", "2026-01-10", "rain", "oops", ""],
        ])
        result = self.cli("import", str(self.csv), "--dry-run")
        self.assertEqual(result.returncode, 1)
        self.assertIn("preview", result.stdout.lower())
        self.assertIn("not saved", result.stdout.lower())
        self.assertIn("without --dry-run", result.stdout)
        for count in ["inserted=1", "updated=0", "unchanged=0", "invalid=1"]:
            self.assertIn(count, result.stdout)
        self.assertIn("row 3:", result.stderr)
        self.assertFalse(self.db.exists())
        saved = self.cli("import", str(self.csv))
        self.assertEqual(saved.returncode, 1)
        self.assertNotIn("preview", saved.stdout.lower())
        self.assertNotIn("not saved", saved.stdout.lower())
        self.assertEqual(self.history()[0][2], "one")

    def test_import_help_explains_preview_and_save_workflow(self):
        result = self.cli("import", "--help")
        self.assertEqual(result.returncode, 0, result.stderr)
        help_text = " ".join(result.stdout.split()).lower()
        self.assertIn("--dry-run", help_text)
        self.assertIn("preview", help_text)
        self.assertIn("without saving", help_text)
        self.assertIn("without --dry-run", help_text)
        self.assertFalse(self.db.exists())

    def test_invalid_database_returns_exit_two_without_changing_bytes(self):
        self.write_rows([["north", "one", "2026-01-10", "rain", "1", ""]])
        self.db.write_bytes(b"not a sqlite database")
        before = self.database_files()
        result = self.cli("import", str(self.csv), "--dry-run", "--json")
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, "")
        self.assertTrue(result.stderr.strip())
        self.assertEqual(self.database_files(), before)


if __name__ == "__main__":
    unittest.main()
