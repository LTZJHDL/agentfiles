# Field Ledger

Field Ledger 是一个使用 Python 标准库和 SQLite 的观测记录命令行工具。它保存导入修订，列出当前记录，并按日期和分类汇总。需要 Python 3.11 或以上版本，无需安装依赖。

先预览 CSV，检查预计新增、更新、未变化的数量和行错误，再正式导入。预览不保存数据，也不创建数据库或目录。

文中的 `python` 指 Python 解释器。本机已有可用的 Python，无需另行安装；在 Windows PowerShell 中进入本目录后，使用 `&` 调用：

```powershell
$python = 'C:\Users\LTZJH\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
& $python -m fieldledger --db observations.sqlite import examples/demo.csv --dry-run
```

文本预览会提示结果尚未保存，并提示移除 `--dry-run` 后导入。若有行错误，按诊断修正 CSV 并重新预览。确认结果后运行同一命令，移除 `--dry-run`：

```powershell
& $python -m fieldledger --db observations.sqlite import examples/demo.csv
& $python -m fieldledger --db observations.sqlite list --json
& $python -m fieldledger --db observations.sqlite report --from 2026-01-01 --to 2026-01-31 --category rain --json
& $python -m unittest discover -s tests -v
```

导入和预览均可添加 `--json` 查看结构化输出，省略它则查看文本输出。`--db` 放在子命令之前，默认使用当前目录的 `observations.sqlite`。正式导入需要数据库父目录已存在且具备写入权限。预览将不存在的数据库视为空库，即使父目录不存在也不会创建它；查询不存在的数据库同样返回空结果，不创建文件。

CSV 的必需列是 `source,external_id,day,category,value`，可选列为 `note`。字段首尾空白会被去掉。`source` 和 `external_id` 共同确定记录身份；重复导入相同内容不会增加修订。改变值、日期、分类或备注会追加一个完整版本。额外具名列被忽略。

导入结果包含新增、更新、未变化和无效行的数量，以及无效行诊断。预览 JSON 在这些字段之外增加 `dry_run: true`，正式导入的 JSON 保持原样。相同 CSV 和数据库在没有外部变化时，预览与正式导入的五个结果字段相同，包括文件内重复标识的处理。

预览和正式导入都使用退出码 `0` 表示成功，`1` 表示存在被跳过的无效行，`2` 表示整份输入或执行失败。正式导入遇到无效行时，其余有效行仍会在同一次事务中提交。缺列、重复列名或文件读取失败不会创建或更改数据库。

预览只读现有数据，不验证写入一定成功，也不锁定或保留后续数据库状态。该工具用于本地顺序操作，不支持并发写入；预览后若 CSV 或数据库发生变化，应重新预览。

日期范围包含两个端点；分类精确匹配。统计从每条记录的最新版本出发，所有总数和分组使用相同的筛选结果。完整规则见 [数据约定](docs/data-contract.md)，内部职责见 [架构说明](docs/architecture.md)。

`examples/incident/initial.csv` 和 `corrections.csv` 展示分批提交观测及后续更正：

```powershell
& $python -m fieldledger --db incident.sqlite import examples/incident/initial.csv --dry-run --json
& $python -m fieldledger --db incident.sqlite import examples/incident/initial.csv --json
& $python -m fieldledger --db incident.sqlite report --from 2026-01-01 --to 2026-01-31 --json
& $python -m fieldledger --db incident.sqlite import examples/incident/corrections.csv --dry-run --json
& $python -m fieldledger --db incident.sqlite import examples/incident/corrections.csv --json
& $python -m fieldledger --db incident.sqlite report --from 2026-01-01 --to 2026-01-31 --json
```

首次导入后，一月包含 4 条当前记录，总值为 25；更正后，一月包含 3 条当前记录，总值为 24。
