import csv
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from fieldledger import store
from fieldledger.importer import import_csv
from fieldledger.model import InputError


HEADER = ["source", "external_id", "day", "category", "value", "note"]
SUMMARY_KEYS = {"inserted", "updated", "unchanged", "invalid", "errors"}


class PreviewTest(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.db = self.root / "ledger.sqlite"
        self.csv = self.root / "input.csv"

    def write_rows(self, rows, header=HEADER):
        with self.csv.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.writer(stream)
            writer.writerow(header)
            writer.writerows(rows)

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, "-m", "fieldledger", "--db", str(self.db), *args],
            capture_output=True, text=True, encoding="utf-8",
            cwd=Path(__file__).resolve().parents[1],
        )

    def baseline(self):
        self.write_rows([
            ["north", "one", "2026-01-10", "rain", "10", "original"],
            ["north", "one", "2026-02-10", "snow", "20", "current"],
            ["north", "steady", "2026-01-10", "rain", "3", ""],
        ])
        import_csv(self.csv, self.db)

    def snapshot(self):
        connection = sqlite3.connect(self.db.resolve().as_uri() + "?mode=ro", uri=True)
        try:
            schema = connection.execute(
                "SELECT type, name, tbl_name, sql FROM sqlite_master ORDER BY name"
            ).fetchall()
            history = connection.execute("SELECT * FROM revisions ORDER BY revision_id").fetchall()
            sequence = connection.execute("SELECT * FROM sqlite_sequence ORDER BY name").fetchall()
        finally:
            connection.close()
        return self.db.read_bytes(), self.db.stat().st_mtime_ns, schema, history, sequence

    def preview_then_import(self, exit_code=0):
        preview = self.cli("import", str(self.csv), "--dry-run", "--json")
        self.assertEqual(preview.returncode, exit_code, preview.stderr)
        result = json.loads(preview.stdout)  # Rejects any prose or additional JSON values.
        self.assertEqual(set(result), SUMMARY_KEYS | {"dry_run"})
        self.assertIs(result.pop("dry_run"), True)
        actual = self.cli("import", str(self.csv), "--json")
        self.assertEqual(actual.returncode, exit_code, actual.stderr)
        saved = json.loads(actual.stdout)
        self.assertEqual(set(saved), SUMMARY_KEYS)
        self.assertEqual(result, saved)
        return result

    def test_existing_history_preview_matches_import_and_preserves_database(self):
        self.baseline()
        self.write_rows([
            ["north", "one", "2026-02-10", "snow", "20", "current"],
            ["north", "one", "2026-01-10", "rain", "10", "original"],
            ["north", "new", "2026-01-10", "rain", "7", ""],
            ["north", "bad", "2026-02-30", "rain", "1", ""],
        ])
        before = self.snapshot()
        directory = set(self.root.iterdir())
        preview = import_csv(self.csv, self.db, dry_run=True).as_dict()
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(set(self.root.iterdir()), directory)
        self.assertEqual([preview[k] for k in ("inserted", "updated", "unchanged", "invalid")],
                         [1, 1, 1, 1])
        self.assertEqual(self.preview_then_import(exit_code=1), preview)

    def test_repeated_identities_use_file_order_and_ignore_invalid_intermediate_row(self):
        self.baseline()
        self.write_rows([
            ["north", "one", "2026-02-10", "snow", "30", "current"],
            ["north", "one", "2026-02-10", "snow", "invalid", "current"],
            ["north", "one", "2026-02-10", "snow", "30", "current"],
            ["north", "one", "2026-02-10", "snow", "20", "current"],
            ["north", "one", "2026-02-10", "snow", "20", "current"],
            ["北:方", "站", "2026-01-10", "rain", "1", ""],
            ["北", "方:站", "2026-01-10", "rain", "1", ""],
            ["北|方", "站", "2026-01-10", "rain", "2", ""],
            ["北", "方|站", "2026-01-10", "rain", "2", ""],
            ["北:方", "站", "2026-01-10", "rain", "2", ""],
            ["北:方", "站", "2026-01-10", "rain", "2", ""],
        ])
        summary = self.preview_then_import(exit_code=1)
        self.assertEqual([summary[k] for k in ("inserted", "updated", "unchanged", "invalid")],
                         [4, 3, 3, 1])
        self.assertEqual(summary["errors"][0]["row"], 3)

    def test_normalization_bom_extra_named_column_and_optional_note(self):
        self.write_rows([["北方", "station:一", "2026-01-10", "rain", "10", ""]])
        import_csv(self.csv, self.db)
        self.csv.write_text(
            "\ufeffsource,external_id,day,category,value,ignored\n"
            " 北方 , station:一 , 2026-01-10 , rain , +0010 ,extra\n",
            encoding="utf-8",
        )
        self.assertEqual(self.preview_then_import(), {
            "inserted": 0, "updated": 0, "unchanged": 1, "invalid": 0, "errors": [],
        })

    def test_multiline_notes_use_csv_record_numbers(self):
        self.write_rows([
            ["north", "one", "2026-01-10", "rain", "1", " two\nlines "],
            ["north", "bad", "not-a-date", "rain", "1", ""],
            ["north", "short"],
            ["north", "extra", "2026-01-10", "rain", "1", "", "extra"],
        ])
        summary = self.preview_then_import(exit_code=1)
        self.assertEqual(summary["inserted"], 1)
        self.assertEqual(summary["invalid"], 3)
        self.assertEqual([error["row"] for error in summary["errors"]], [3, 4, 5])
        self.assertTrue(all(error["message"] for error in summary["errors"]))
        self.assertEqual(store.read_current(self.db)[0].note, "two\nlines")

    def test_missing_database_and_missing_parents_are_not_created(self):
        self.write_rows([["north", "one", "2026-01-10", "rain", "1", ""]])
        for database in [self.db, self.root / "absent" / "nested" / "ledger.sqlite"]:
            with self.subTest(database=database):
                self.db = database
                before = set(self.root.rglob("*"))
                self.assertEqual(import_csv(self.csv, self.db, dry_run=True).inserted, 1)
                result = self.cli("import", str(self.csv), "--dry-run", "--json")
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(json.loads(result.stdout)["inserted"], 1)
                self.assertEqual(set(self.root.rglob("*")), before)

    def test_whole_input_errors_leave_missing_database_absent(self):
        invalid_inputs = [
            b"", b"source,external_id\nnorth,one\n",
            b"source,external_id,day,category,value,value\n",
            b"source,external_id,day,category,value,\n",
            b"source,external_id,day,category,value\n\xff",
            b'source,external_id,day,category,value\n"unterminated',
        ]
        for database in [self.db, self.root / "absent" / "nested" / "ledger.sqlite"]:
            self.db = database
            for content in invalid_inputs:
                with self.subTest(database=database, content=content):
                    self.csv.write_bytes(content)
                    before = set(self.root.rglob("*"))
                    result = self.cli("import", str(self.csv), "--dry-run", "--json")
                    self.assertEqual(result.returncode, 2)
                    self.assertEqual(result.stdout, "")
                    self.assertTrue(result.stderr.strip())
                    self.assertEqual(set(self.root.rglob("*")), before)
            with self.subTest(database=database, missing_input=True):
                before = set(self.root.rglob("*"))
                result = self.cli("import", str(self.root / "missing.csv"), "--dry-run", "--json")
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, "")
                self.assertTrue(result.stderr.strip())
                self.assertEqual(set(self.root.rglob("*")), before)

    def test_whole_input_error_preserves_existing_database(self):
        self.baseline()
        before = self.snapshot()
        self.csv.write_bytes(b"source,external_id,day,category,value\n\xff")
        with self.assertRaises(InputError):
            import_csv(self.csv, self.db, dry_run=True)
        self.assertEqual(self.snapshot(), before)

    def test_all_invalid_rows_and_header_only_do_not_create_database(self):
        for rows, expected_exit in [([], 0), ([["north", "short"], ["", "bad"]], 1)]:
            with self.subTest(rows=rows):
                self.write_rows(rows)
                result = self.cli("import", str(self.csv), "--dry-run", "--json")
                self.assertEqual(result.returncode, expected_exit, result.stderr)
                summary = json.loads(result.stdout)
                self.assertIs(summary["dry_run"], True)
                self.assertEqual([summary[k] for k in ("inserted", "updated", "unchanged")], [0, 0, 0])
                self.assertEqual(summary["invalid"], len(rows))
                self.assertEqual(len(summary["errors"]), len(rows))
                self.assertFalse(self.db.exists())

    def test_service_preview_only_uses_readonly_connections_and_never_appends(self):
        self.baseline()
        self.write_rows([["north", "one", "2026-01-10", "rain", "99", ""]])
        before = self.snapshot()
        real_connect = sqlite3.connect

        def readonly_connect(database, *args, **kwargs):
            self.assertTrue(kwargs.get("uri"), "preview opened a non-URI connection")
            self.assertIn("mode=ro", str(database), "preview opened a writable connection")
            return real_connect(database, *args, **kwargs)

        with patch.object(store, "connect", side_effect=AssertionError("writable store connection")), \
                patch.object(store, "append_revision", side_effect=AssertionError("revision append")), \
                patch.object(sqlite3, "connect", side_effect=readonly_connect):
            summary = import_csv(self.csv, self.db, dry_run=True)
        self.assertEqual(summary.updated, 1)
        self.assertEqual(self.snapshot(), before)

    def test_existing_empty_sqlite_file_is_read_without_initializing_schema(self):
        sqlite3.connect(self.db).close()
        self.write_rows([["north", "one", "2026-01-10", "rain", "1", ""]])
        before = self.db.read_bytes(), self.db.stat().st_mtime_ns
        self.assertEqual(import_csv(self.csv, self.db, dry_run=True).inserted, 1)
        self.assertEqual((self.db.read_bytes(), self.db.stat().st_mtime_ns), before)
        self.assertEqual(self.preview_then_import()["inserted"], 1)

    def test_readonly_database_file_can_be_previewed(self):
        self.db = self.root / "观测 #100%.sqlite"
        self.baseline()
        self.write_rows([["north", "one", "2026-01-10", "rain", "99", ""]])
        before = self.snapshot()
        original_mode = self.db.stat().st_mode
        self.db.chmod(0o444)
        try:
            result = self.cli("import", str(self.csv), "--json", "--dry-run")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout), {
                "inserted": 0, "updated": 1, "unchanged": 0, "invalid": 0,
                "errors": [], "dry_run": True,
            })
            self.assertEqual(self.snapshot(), before)
        finally:
            self.db.chmod(original_mode)

    def test_human_preview_explains_unsaved_changes_and_how_to_import(self):
        self.write_rows([
            ["north", "one", "2026-01-10", "rain", "1", ""],
            ["north", "bad", "2026-01-10", "rain", "oops", ""],
        ])
        result = self.cli("import", str(self.csv), "--dry-run")
        self.assertEqual(result.returncode, 1, result.stderr)
        self.assertIn("preview", result.stdout.lower())
        self.assertRegex(result.stdout.lower(), r"(no changes saved|not saved|nothing saved|unsaved)")
        self.assertIn("inserted=1", result.stdout)
        self.assertIn("invalid=1", result.stdout)
        self.assertRegex(result.stdout.lower(), r"(without|remove|omit).*--dry-run")
        self.assertIn("row 3:", result.stderr)
        self.assertFalse(self.db.exists())
        help_result = self.cli("import", "--help")
        self.assertEqual(help_result.returncode, 0, help_result.stderr)
        self.assertIn("--dry-run", help_result.stdout)


if __name__ == "__main__":
    unittest.main()
