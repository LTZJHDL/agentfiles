# Field Ledger

Field Ledger 是一个使用 Python 标准库和 SQLite 的观测记录命令行工具。它保存导入修订，列出当前记录，并按日期和分类汇总。需要 Python 3.11 或以上版本，无需安装依赖。

在本目录先预览。下面的 `python` 指本机 Python 解释器；在 Windows PowerShell 中可将它替换为 `& 'C:\Users\LTZJH\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'`。

```console
python -m fieldledger --db observations.sqlite import examples/demo.csv --dry-run
```

如果数据库尚不存在，示例预览输出为：

```text
Preview only: no changes saved.
inserted=4 updated=0 unchanged=0 invalid=0
To import and save these changes, rerun the same command without --dry-run.
```

`inserted`、`updated`、`unchanged`、`invalid` 分别表示新增、更新、未变化和无效行数。无效行的记录序号和原因显示在 stderr；序号从表头后的 2 开始，含换行的备注仍算一条记录。先检查这些结果，必要时修改 CSV 并重新预览。确认要保存后，移除 `--dry-run`，使用相同数据库和 CSV 正式导入：

```console
python -m fieldledger --db observations.sqlite import examples/demo.csv
python -m fieldledger --db observations.sqlite list --json
```

预览不会创建或修改数据库、初始化表或追加修订；数据库和父目录不存在时也不会创建它们，而是按空数据库预览。已有数据库只需可读。正式导入需要可写数据库，且父目录须已存在。`--db` 放在子命令之前，默认使用当前目录的 `observations.sqlite`。

预览也支持 JSON，适合脚本读取：

```console
python -m fieldledger --db observations.sqlite import observations.csv --dry-run --json
```

JSON 的 stdout 只包含一个对象，含 `inserted`、`updated`、`unchanged`、`invalid`、`errors` 和 `dry_run: true`。每条 `errors` 包含 `row` 和 `message`；没有错误时为空数组。正式导入的 JSON 保持原有五项，不添加 `dry_run` 字段。省略 `--json` 可查看文本输出。使用 `python -m fieldledger import --help` 查看选项。

预览与正式导入共用解析、校验和变更判断规则。同一文件中的重复标识按文件顺序处理，后续有效行以先前有效行处理后的状态为准，因此这些计数统计的是行，不是最终不同记录的数量。数据库和输入没有变化时，预览与随后成功执行的正式导入的四个计数及 `errors` 完全一致。工具面向没有并发写入的本地使用；预览不会锁定后续状态，也不验证写入权限或保证之后的磁盘写入成功。

继续查询和验证：

```console
python -m fieldledger --db observations.sqlite report --from 2026-01-01 --to 2026-01-31 --category rain --json
python -m unittest discover -s tests -v
```

查询不存在的数据库会返回空结果，不创建文件。

CSV 的必需列是 `source,external_id,day,category,value`，可选列为 `note`。字段首尾空白会被去掉。`source` 和 `external_id` 共同确定记录身份；重复导入相同内容不会增加修订。改变值、日期、分类或备注会追加一个完整版本。额外具名列被忽略。

预览和正式导入沿用同样的退出码：`0` 表示成功且没有无效行，`1` 表示存在被跳过的无效行，`2` 表示整份输入或执行失败。退出码 `1` 不会阻止正式导入保存其余有效行，这些有效行仍在同一次事务中提交；预览始终不保存。缺列、重复列名或文件读取失败时，stderr 说明原因，stdout 不输出摘要，也不会创建或更改数据库。

日期范围包含两个端点；分类精确匹配。统计从每条记录的最新版本出发，所有总数和分组使用相同的筛选结果。完整规则见 [数据约定](docs/data-contract.md)，内部职责见 [架构说明](docs/architecture.md)。

`examples/incident/initial.csv` 和 `corrections.csv` 展示分批提交观测及后续更正：

```console
python -m fieldledger --db incident.sqlite import examples/incident/initial.csv --json
python -m fieldledger --db incident.sqlite report --from 2026-01-01 --to 2026-01-31 --json
python -m fieldledger --db incident.sqlite import examples/incident/corrections.csv --json
python -m fieldledger --db incident.sqlite report --from 2026-01-01 --to 2026-01-31 --json
```

首次导入后，一月包含 4 条当前记录，总值为 25；更正后，一月包含 3 条当前记录，总值为 24。
